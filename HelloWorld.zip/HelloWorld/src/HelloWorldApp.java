/*
HelloWorld Demonstration
Rachel Creemers
1/10/24
*/

public class HelloWorldApp {  /* the class at the top has to be the same name as the file name to get it to compile */
    public static void main (String[] args) {  /* this is the main function */
        System.out.println("Hello World");

    }
}