/******
Name: Rachel Creemers
Assignment: Lab 0
Date: 1.12.2024
Notes: The price is going to be a float, so watch for that
******/

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
 
public class BookTest {
	
	private Book mybook;
	private Person murderbot;

	
	/**
	 *  This is just the setup, putting in variables and such
	 */
	@Before
	public void setUp() {
		murderbot = new Person("Sec", "Unit", 3015);
		mybook = new Book("The Murderbot Diaries", murderbot, 10);
	}
	
	/**
	 * Test the getTitle() function
	 */
	@Test
	public void testGetTitle() {
		assertEquals("The Murderbot Diaries", mybook.getTitle());
	}
	
	/**
	 * Test the testGetPrice() function
	 */
	@Test
	public void testGetPrice() {
		assertTrue(Math.abs(10 - mybook.getPrice()) <= .00001);
	}
	
	/**
	 *  Test the testGetAuthor() function
	 */
	@Test
	public void testGetAuthor() {
		assertEquals(murderbot, mybook.getAuthor());
	}

}
